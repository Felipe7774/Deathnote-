package models

import (
	"gorm.io/gorm"
)

type Persona struct {
	ID       uint   `gorm:"primaryKey"`
	Nombre   string `json:"nombre"`
	Foto     string `json:"Foto"`
	Causa    string `json:"causa,omitempty"`
	Detalles string `json:"detalles,omitempty"`
	gorm.Model
}
