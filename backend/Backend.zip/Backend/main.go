package main

import (
	"deathnote/database"
	"deathnote/models"
	"log"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func main() {
	// Conectar a la base de datos
	database.InitDB()

	// Asegurar que la tabla está correctamente migrada
	if err := database.DB.AutoMigrate(&models.Persona{}); err != nil {
		log.Fatalf("Error al migrar la tabla personas: %v", err)
	}

	r := gin.Default()

	// Habilitar CORS para permitir solicitudes desde el frontend
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"http://localhost:3000"},
		AllowMethods:     []string{"GET", "POST", "OPTIONS"},
		AllowHeaders:     []string{"Origin", "Content-Type"},
		AllowCredentials: true,
	}))

	// Ruta de prueba
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{"message": "pong"})
	})

	// Registrar persona con manejo de errores
	r.POST("/registrar", func(c *gin.Context) {
		var request models.Persona
		if err := c.BindJSON(&request); err != nil {
			c.JSON(400, gin.H{"error": "Datos inválidos"})
			return
		}

		// Validar datos obligatorios
		if request.Nombre == "" || request.Foto == "" {
			c.JSON(400, gin.H{"error": "El nombre y la foto son obligatorios"})
			return
		}

		// Insertar en la base de datos con manejo de errores
		if err := database.DB.Create(&request).Error; err != nil {
			c.JSON(500, gin.H{"error": "No se pudo registrar en la base de datos", "detalle": err.Error()})
			return
		}

		c.JSON(201, gin.H{"message": "Persona registrada", "data": request})
	})

	// Listar fallecidos, ordenados por fecha de registro
	r.GET("/fallecidos", func(c *gin.Context) {
		var fallecidos []models.Persona
		if err := database.DB.Order("id DESC").Find(&fallecidos).Error; err != nil {
			c.JSON(500, gin.H{"error": "No se pudieron obtener los registros", "detalle": err.Error()})
			return
		}
		c.JSON(200, fallecidos)
	})

	r.Run(":8080") // Arranca el servidor
}
