package database

import (
	"log"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// Definir la cadena de conexión directamente
var dsn = "host=deathnote-db user=postgres password=tajj dbname=deathnote port=5432 sslmode=disable"

var DB *gorm.DB

func InitDB() {
	var err error
	DB, err = gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatal("Error al conectar a la base de datos:", err)
	}
	log.Println("Conexión a la base de datos exitosa")
}
